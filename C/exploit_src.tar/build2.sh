gcc suid_bin2.c -o suid_bin2.bin && chown root:root suid_bin2.bin
