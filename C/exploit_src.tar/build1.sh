gcc suid_bin1.c -o suid_bin1.bin && chown root:root suid_bin1.bin && chmod 4771 suid_bin1.bin
